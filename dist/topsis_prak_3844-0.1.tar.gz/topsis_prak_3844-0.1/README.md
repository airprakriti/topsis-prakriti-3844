 
# TOPSIS-PRAK-3844

This Python package implements the **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** method for multi-criteria decision-making.

## Installation

```bash
pip install topsis-prak-3844
